## Hola 👋

Puede acceder a la lectura de la clase en: [https://lectures-r.gitlab.io/uniandes-202202/lecture-5](https://lectures-r.gitlab.io/uniandes-202202/lecture-5)

